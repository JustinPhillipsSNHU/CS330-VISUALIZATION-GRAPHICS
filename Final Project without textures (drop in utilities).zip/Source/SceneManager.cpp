///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the various material
 *  settings for all of the objects within the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Outlet material (plastic)
	OBJECT_MATERIAL outletMaterial;
	outletMaterial.ambientStrength = 0.2f;
	outletMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	outletMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	outletMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	outletMaterial.shininess = 10.0f;
	outletMaterial.tag = "outlet";
	m_objectMaterials.push_back(outletMaterial);

	// Steel material (metal)
	OBJECT_MATERIAL steelMaterial;
	steelMaterial.ambientStrength = 0.3f;
	steelMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	steelMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	steelMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	steelMaterial.shininess = 50.0f;
	steelMaterial.tag = "steel";
	m_objectMaterials.push_back(steelMaterial);

	// Drywall material (matte surface)
	OBJECT_MATERIAL drywallMaterial;
	drywallMaterial.ambientStrength = 0.1f;
	drywallMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	drywallMaterial.diffuseColor = glm::vec3(0.7f, 0.7f, 0.7f);
	drywallMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	drywallMaterial.shininess = 1.0f;
	drywallMaterial.tag = "drywall";
	m_objectMaterials.push_back(drywallMaterial);

	// Wood material (wooden surface)
	OBJECT_MATERIAL wood_material;
	wood_material.ambientStrength = 0.2f;
	wood_material.ambientColor = glm::vec3(0.3f, 0.2f, 0.1f);
	wood_material.diffuseColor = glm::vec3(0.6f, 0.4f, 0.2f);
	wood_material.specularColor = glm::vec3(0.3f, 0.2f, 0.1f);
	wood_material.shininess = 10.0f;
	wood_material.tag = "wood";
	m_objectMaterials.push_back(wood_material);

	// Vent material (metal)
	OBJECT_MATERIAL ventMaterial;
	ventMaterial.ambientStrength = 0.3f;
	ventMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	ventMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	ventMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	ventMaterial.shininess = 50.0f;
	ventMaterial.tag = "vent";
	m_objectMaterials.push_back(ventMaterial);

	OBJECT_MATERIAL furMaterial;
	furMaterial.ambientStrength = 0.4f;
	furMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	furMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	furMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
	furMaterial.tag = "fur";
	m_objectMaterials.push_back(furMaterial);



}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting - to use the default rendered 
	// lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Intensities
	float roomIntensity = 1.0f;
	float windowIntensity = 0.35f;

	// Room LED
	m_pShaderManager->setVec3Value("lightSources[0].position", -30.0f, 50.0f, 70.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.7f * roomIntensity, 0.7f * roomIntensity, 0.7f * roomIntensity); // Slightly brighter ambient light
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.8f * roomIntensity, 0.8f * roomIntensity, 0.9f * roomIntensity); // Cool white diffuse light
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.9f * roomIntensity, 0.9f * roomIntensity, 1.0f * roomIntensity); // Bright specular highlights
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 1.0f * roomIntensity); // Strong light
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.8f * roomIntensity); // Strong specular intensity
	
	// Window light
	m_pShaderManager->setVec3Value("lightSources[1].position", 18.0f, 120.0f, -120.0f); 
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.8f * windowIntensity, 0.7f * windowIntensity, 0.5f * windowIntensity); // Warm ambient light
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.9f * windowIntensity, 0.8f * windowIntensity, 0.6f * windowIntensity); // Soft yellow diffuse light
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.9f * windowIntensity, 0.8f * windowIntensity, 0.6f * windowIntensity); // Warm specular highlights
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 0.5f * windowIntensity); // Softer light
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.5f * windowIntensity); // Softer specular intensity
}


/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/

void SceneManager::LoadSceneTextures() {
	bool bReturn = false;

	bReturn = CreateGLTexture("../../Utilities/Textures/vent.jpg", "vent");
	bReturn = CreateGLTexture("../../Utilities/Textures/wood_horizontal.jpg", "wood_h");
	bReturn = CreateGLTexture("../../Utilities/Textures/wood_vertical.jpg", "wood_v");
	bReturn = CreateGLTexture("../../Utilities/Textures/stainless.jpg", "steel");
	bReturn = CreateGLTexture("../../Utilities/Textures/grey_drywall.jpg", "drywall");
	bReturn = CreateGLTexture("../../Utilities/Textures/dark_grey_outlets.jpg", "outlet");
	bReturn = CreateGLTexture("../../Utilities/Textures/luka_face_texture.png", "fur_face");
	bReturn = CreateGLTexture("../../Utilities/Textures/luka_chest.png", "fur_chest");
	bReturn = CreateGLTexture("../../Utilities/Textures/luka_left_side.png", "fur_left");
	bReturn = CreateGLTexture("../../Utilities/Textures/luka_right_side.png", "fur_right");
	bReturn = CreateGLTexture("../../Utilities/Textures/luka_nose.png", "fur_nose");

	BindGLTextures();
}

void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	LoadSceneTextures();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh(0.07f);
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0, 0, 0, 1);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	// POST NEXT TO WALL /////////////////////////////////////////////
	scaleXYZ = glm::vec3(1.0f, 20.0f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(4.0f, 0.0f, -2.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// BACK WALL ///////////////////////////////////////////////////////
	scaleXYZ = glm::vec3(8.0f, 1.0f, 20.0f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f, -2.2f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.75f, 0.75f, 0.65f, 1.0f);
	SetShaderTexture("drywall");
	SetShaderMaterial("drywall");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// OUTLET //////////////////////////////////////////////////////////
	// The outlet is composed of a white box, with two flat cylinders aligned to 
	// the center, and flushly facing horizontally, stretched wide and compressed short.
	// The outlet is slightly to the right of the chair.
	// OUTLET POSITION
	glm::vec3 outletPositionModifier = glm::vec3(0.0f, -2.2f, -1.0f);
	// OUTLET SCALE
	glm::vec3 outletScaleModifier = glm::vec3(1.0f, 1.0f, 1.0f);
	// OUTLET ROTATION
	float outletRotationModifierX = 0.0f;
	float outletRotationModifierY = 0.0f;
	float outletRotationModifierZ = 0.0f;


	// OUTLET BOX ///////////////////////////////////////////////////////
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f) * outletScaleModifier;
	XrotationDegrees = 0.0f + outletRotationModifierX;
	YrotationDegrees = 0.0f + outletRotationModifierY;
	ZrotationDegrees = 0.0f + outletRotationModifierZ;
	positionXYZ = glm::vec3(0.0f, scaleXYZ[1] / 2, 0.0f) + outletPositionModifier;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.75f, 0.75f, 0.65f, 1.0f);
	SetShaderTexture("outlet");
	SetShaderMaterial("outlet");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_LINEAR);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// VENT ////////////////////////////////////////////////////////////
	// The vent is composed of a gray box, with a flat cylinder aligned to the center,
	// and flushly facing horizontally, stretched wide and compressed short.
	// The vent is slightly to the right of the chair.
	// VENT POSITION
	glm::vec3 ventPositionModifier = glm::vec3(-2.0f, 0.6f, -1.73f);
	// VENT SCALE
	glm::vec3 ventScaleModifier = glm::vec3(3.0f, 3.0f, 1.0f);
	// VENT ROTATION
	float ventRotationModifierX = 0.0f;
	float ventRotationModifierY = 0.0f;
	float ventRotationModifierZ = 0.0f;

	// VENT BOX ////////////////////////////////////////////////////////
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.1f) * ventScaleModifier;
	XrotationDegrees = 0.0f + ventRotationModifierX;
	YrotationDegrees = 0.0f + ventRotationModifierY;
	ZrotationDegrees = 0.0f + ventRotationModifierZ;
	positionXYZ = glm::vec3(0.0f, scaleXYZ[1] / 2, 0.0f) + ventPositionModifier;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.75f, 0.75f, 0.65f, 1.0f);
	SetShaderTexture("vent");
	SetShaderMaterial("vent");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();


	// FRIDGE //////////////////////////////////////////////////////////
	// The fridge is composed of a gray box.
	// The fridge is on the far left of the composition, and slightly back.
	scaleXYZ = glm::vec3(4.0f, 8.0f, 4.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-5.0f, (scaleXYZ[1] / 2), -1.1f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.5f, 0.5f, 0.5f, 1.0f);
	SetShaderTexture("steel");
	SetShaderMaterial("steel");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();



	// CHAIR //////////////////////////////////////////////////////////
	// The chair is composed of a top and bottom half.
	// The top half is a flattened cylinder, with a back composed of 
	// eight cylinders acting as "bars"
	// and an elongated half-torus, to act as the back of the chair.

	// The bottom of the chair is composed four legs with cylinders, 
	// and between the legs are two rungs of cylinders branching 
	// laterally betwixt them. 

	// It is worth noting that the rungs on the left amd right sides
	// respective to the rungs on the back and front of the chair are 
	// slightly raised.

	// The chair is a brown color, and the seat of the top of the chair
	// is actually more resembling of a rounded square.

	// The chair itself has a position slightly to the left side of the 
	// composition.

	// FULL CHAIR VARIABLES
	// Spatial modifier for the chair.
	glm::vec3 chairPositionModifier = glm::vec3(-1.0f, 0.0f, 0.0f);
	// Scale modifier for the chair.
	glm::vec3 chairScaleModifier = glm::vec3(1.0f, 1.0f, 1.0f);
	// Rotation modifier for the chair.
	float chairRotationModifierX = 0.0f;
	float chairRotationModifierY = 0.0f;
	float chairRotationModifierZ = 0.0f;


	// TOP HALF ///////////////////////////////////////////////////////
	// SEAT	///////////////////////////////////////////////////////////
	scaleXYZ = glm::vec3(1.1f, 0.07f, 0.9f) * chairScaleModifier;
	XrotationDegrees = 0.0f + chairRotationModifierX;
	YrotationDegrees = 0.0f + chairRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(0, scaleXYZ[1] / 2, 0) + chairPositionModifier;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.5f, 0.25f, 0.0f, 1.0f);
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// BACK	///////////////////////////////////////////////////////////
	float chairBackRotationModifierX = -15.0f + chairRotationModifierX;
	float chairBackRotationModifierY = 0.0f + chairRotationModifierY;
	float chairBackRotationModifierZ = 0.0f + chairRotationModifierZ;
	glm::vec3 chairBackPositionModifier = glm::vec3(0.0f, -0.25f, 0.0f) + chairPositionModifier;
	glm::vec3 chairBackScaleModifier = glm::vec3(1.0f, 1.3f, 1.0f) * chairScaleModifier;

	// HALF-TORUS /////////////////////////////////////////////////////
	scaleXYZ = glm::vec3(1.0f, 1.5f, 1.1f) * chairBackScaleModifier;
	XrotationDegrees = 0.0f + chairBackRotationModifierX;
	YrotationDegrees = 0.0f + chairBackRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(0.0f, (scaleXYZ[1] / 2), -0.65f) + chairBackPositionModifier;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.5f, 0.25f, 0.0f, 1.0f);
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	// BARS	///////////////////////////////////////////////////////////
	// CYLINDERS //////////////////////////////////////////////////////
	// Compose eight cylinders to act as the back of the chair. I attempted a for loop,
	// but it was not working as intended, so I manually placed each cylinder.

	// Float for cylinder height scaler, for easy scaling to the torus.
	float cylinderHeightScaler = 7.0f;

	// Float for cylinder width scaler, for easy scaling to the torus.
	float cylinderWidthScaler = 0.5f;

	// Position matrix modifier, for easily moving all the cylinders at once.
	glm::vec3 chairBackCylinderPositionModifier = glm::vec3(0.0f, -1.05f, -0.5f);

	// Cylinder 1
	// Vertical, and leftmost bar.
	scaleXYZ = glm::vec3(0.1f * cylinderWidthScaler, 0.255f * cylinderHeightScaler, 0.1f * cylinderWidthScaler) * chairBackScaleModifier;
	XrotationDegrees = 0.0f + chairBackRotationModifierX;
	YrotationDegrees = 0.0f + chairBackRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(0.7f, scaleXYZ[1] / 2, 0.0f) + chairBackCylinderPositionModifier + chairBackPositionModifier;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.5f, 0.25f, 0.0f, 1.0f);
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Cylinder 2
	// Vertical, and rightmost bar.
	scaleXYZ = glm::vec3(0.1f * cylinderWidthScaler, 0.255f * cylinderHeightScaler, 0.1f * cylinderWidthScaler) * chairBackScaleModifier;
	XrotationDegrees = 0.0f + chairBackRotationModifierX;
	YrotationDegrees = 0.0f + chairBackRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(-0.7f, scaleXYZ[1] / 2, 0.0f) + chairBackCylinderPositionModifier + chairBackPositionModifier;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Cylinder 3
	// Vertical, second from left bar.
	scaleXYZ = glm::vec3(0.1f * cylinderWidthScaler, 0.265f * cylinderHeightScaler, 0.1f * cylinderWidthScaler) * chairBackScaleModifier;
	XrotationDegrees = 0.0f + chairBackRotationModifierX;
	YrotationDegrees = 0.0f + chairBackRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(-0.5f, scaleXYZ[1] / 2, 0.0f) + chairBackCylinderPositionModifier + chairBackPositionModifier;
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Cylinder 4
	// Vertical, second from right bar.
	scaleXYZ = glm::vec3(0.1f * cylinderWidthScaler, 0.265f * cylinderHeightScaler, 0.1f * cylinderWidthScaler) * chairBackScaleModifier;
	XrotationDegrees = 0.0f + chairBackRotationModifierX;
	YrotationDegrees = 0.0f + chairBackRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(0.5f, scaleXYZ[1] / 2, 0.0f) + chairBackCylinderPositionModifier + chairBackPositionModifier;
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Cylinder 5
	// Vertical, third from left bar.
	scaleXYZ = glm::vec3(0.1f * cylinderWidthScaler, 0.285f * cylinderHeightScaler, 0.1f * cylinderWidthScaler) * chairBackScaleModifier;
	XrotationDegrees = 0.0f + chairBackRotationModifierX;
	YrotationDegrees = 0.0f + chairBackRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(-0.3f, scaleXYZ[1] / 2, 0.0f) + chairBackCylinderPositionModifier + chairBackPositionModifier;
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Cylinder 6
	// Vertical, third from right bar.
	scaleXYZ = glm::vec3(0.1f * cylinderWidthScaler, 0.285f * cylinderHeightScaler, 0.1f * cylinderWidthScaler) * chairBackScaleModifier;
	XrotationDegrees = 0.0f + chairBackRotationModifierX;
	YrotationDegrees = 0.0f + chairBackRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(0.3f, scaleXYZ[1] / 2, 0.0f) + chairBackCylinderPositionModifier + chairBackPositionModifier;
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Cylinder 7
	// Vertical, center left bar.
	scaleXYZ = glm::vec3(0.1f * cylinderWidthScaler, 0.3f * cylinderHeightScaler, 0.1f * cylinderWidthScaler) * chairBackScaleModifier;
	XrotationDegrees = 0.0f + chairBackRotationModifierX;
	YrotationDegrees = 0.0f + chairBackRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(-0.1f, scaleXYZ[1] / 2, 0.0f) + chairBackCylinderPositionModifier + chairBackPositionModifier;
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// Cylinder 8
	// Vertical, center right bar.
	scaleXYZ = glm::vec3(0.1f * cylinderWidthScaler, 0.3f * cylinderHeightScaler, 0.1f * cylinderWidthScaler) * chairBackScaleModifier;
	XrotationDegrees = 0.0f + chairBackRotationModifierX;
	YrotationDegrees = 0.0f + chairBackRotationModifierY;
	ZrotationDegrees = 0.0f + chairRotationModifierZ;
	positionXYZ = glm::vec3(0.1f, scaleXYZ[1] / 2, 0.0f) + chairBackCylinderPositionModifier + chairBackPositionModifier;
	SetShaderTexture("wood_v");
	SetShaderMaterial("wood");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	// CAT ////////////////////////////////////////////////////////////
	// The cat sits upon the chair. He is laying on his belly, slightly curving his body
	// along the natural curve of the chair. His tail is curled around his hind legs, and 
	// his left foreleg sits underneath him. He gives the impression of sitting at a bar and
	// leaning over the counter.

	// CAT BODY
	glm::vec3 catBodyPositionModifier = glm::vec3(-1.3f, 0.2f, 0.3f); // Adjust position to sit on the chair
	glm::vec3 catBodyScaleModifier = glm::vec3(1.0f, 1.0f, 1.0f);
	float catBodyRotationModifierX = 0.0f;
	float catBodyRotationModifierY = 0.0f;
	float catBodyRotationModifierZ = 0.0f;

	// CAT BODY FRONT TORSO
	scaleXYZ = glm::vec3(0.5f, 0.3f, 0.5f) * catBodyScaleModifier;
	XrotationDegrees = 0.0f + catBodyRotationModifierX;
	YrotationDegrees = 40.0f + catBodyRotationModifierY;
	ZrotationDegrees = 0.0f + catBodyRotationModifierZ;
	positionXYZ = glm::vec3(0.5f, scaleXYZ[1] / 2, 0.0f) + catBodyPositionModifier;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetShaderTexture("fur_chest");
	SetShaderMaterial("fur");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// CAT ARMS
	// CAT LEFT ARM
	scaleXYZ = glm::vec3(0.1f, 0.1f, 0.5f) * catBodyScaleModifier;
	positionXYZ = glm::vec3(0.8f, -0.1f, 0.0f) + catBodyPositionModifier;
	XrotationDegrees = 0.0f + catBodyRotationModifierX;
	YrotationDegrees = 0.0f + catBodyRotationModifierY;
	ZrotationDegrees = 0.0f + catBodyRotationModifierZ;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetShaderTexture("fur_chest");
	SetShaderMaterial("fur");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// CAT RIGHT ARM
	positionXYZ = glm::vec3(0.1f, -0.1f, 0.0f) + catBodyPositionModifier;
	XrotationDegrees = 0.0f + catBodyRotationModifierX;
	YrotationDegrees = 0.0f + catBodyRotationModifierY;
	ZrotationDegrees = 0.0f + catBodyRotationModifierZ;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetShaderTexture("fur_chest");
	SetShaderMaterial("fur");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();


	// CAT BODY MIDDLE
	scaleXYZ = glm::vec3(0.25f, 0.6f, 0.45f) * catBodyScaleModifier;
	positionXYZ = glm::vec3(0.35f, (scaleXYZ[1] / 2) + -0.15f, -0.5f) + catBodyPositionModifier;
	XrotationDegrees = 0.0f + catBodyRotationModifierX;
	YrotationDegrees = 110.0f + catBodyRotationModifierY;
	ZrotationDegrees = 90.0f + catBodyRotationModifierZ;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetShaderTexture("fur_right");
	SetShaderMaterial("fur");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// CAT BODY BACK TORSO
	scaleXYZ = glm::vec3(0.5f, 0.3f, 0.5f) * catBodyScaleModifier;
	positionXYZ = glm::vec3(0.3f, scaleXYZ[1] / 2, -0.5f) + catBodyPositionModifier;
	XrotationDegrees = 0.0f + catBodyRotationModifierX;
	YrotationDegrees = 0.0f + catBodyRotationModifierY;
	ZrotationDegrees = 0.0f + catBodyRotationModifierZ;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetShaderTexture("fur_left");
	SetShaderMaterial("fur");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// CAT TAIL, BASE TOUCHING BODY
	scaleXYZ = glm::vec3(0.1f, 0.1f, 0.5f) * catBodyScaleModifier;
	positionXYZ = glm::vec3(-0.05f, -0.1f, -0.85f) + catBodyPositionModifier;
	XrotationDegrees = 0.0f + catBodyRotationModifierX;
	YrotationDegrees = 130.0f + catBodyRotationModifierY;
	ZrotationDegrees = 0.0f + catBodyRotationModifierZ;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetShaderTexture("fur_right");
	SetShaderMaterial("fur");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// CAT TAIL, NEXT SEGMENT (MIDDLE)
	scaleXYZ = glm::vec3(0.1f, 0.1f, 0.3f) * catBodyScaleModifier;
	positionXYZ = glm::vec3(-0.4f, -0.1f, -0.22f) + catBodyPositionModifier;
	XrotationDegrees = 0.0f + catBodyRotationModifierX;
	YrotationDegrees = 0.0f + catBodyRotationModifierY;
	ZrotationDegrees = 0.0f + catBodyRotationModifierZ;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetShaderTexture("fur_right");
	SetShaderMaterial("fur");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// CAT TAIL, END
	scaleXYZ = glm::vec3(0.1f, 0.1f, 0.3f) * catBodyScaleModifier;
	positionXYZ = glm::vec3(-0.45f, -0.15f, 0.3f) + catBodyPositionModifier;
	XrotationDegrees = 10.0f + catBodyRotationModifierX;
	YrotationDegrees = -10.0f + catBodyRotationModifierY;
	ZrotationDegrees = -15.0f + catBodyRotationModifierZ;
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetShaderTexture("fur_right");
	SetShaderMaterial("fur");
	glTextureParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// CAT HEAD
 	glm::vec3 catHeadPositionModifier = glm::vec3(-0.9f, 0.2f, 0.4f); // Adjust position to sit on the chair
	glm::vec3 catHeadScaleModifier = glm::vec3(0.5f, 0.5f, 0.5f);
	float catHeadRotationModifierX = 0.0f;
	float catHeadRotationModifierY = -10.0f;
	float catHeadRotationModifierZ = 0.0f;
	// CAT HEAD
	scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f) * catHeadScaleModifier;
	positionXYZ = glm::vec3(0.0f, scaleXYZ[1] / 2 + 0.3f, 0.3f) + catHeadPositionModifier;
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("fur_face");
	SetShaderMaterial("fur");
	m_basicMeshes->DrawSphereMesh();

	// CAT EARS
	// Left Ear
	scaleXYZ = glm::vec3(0.2f, 0.4f, 0.1f) * catHeadScaleModifier;
	positionXYZ = glm::vec3(-0.1f, scaleXYZ[1] + 0.4f, 0.2f) + catHeadPositionModifier;
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 45.0f, positionXYZ); // Slightly rotated for a natural look
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("fur_left");
	SetShaderMaterial("fur");
	m_basicMeshes->DrawConeMesh();

	// Right Ear
	positionXYZ = glm::vec3(0.1f, scaleXYZ[1] + 0.4f, 0.2f) + catHeadPositionModifier;
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -45.0f, positionXYZ); // Slightly rotated for a natural look
	//SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f);
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("fur_right");
	SetShaderMaterial("fur");
	m_basicMeshes->DrawConeMesh();

}
